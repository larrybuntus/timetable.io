<div class="overlay spec-ajax" trigger="#updateUser"></div>
<div class="modal fade" id="myModal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
    <div class="modal-dialog">
      <div class="modal-content">
	      <div class="modal-header">
	        <button type="button" class="close" data-dismiss="modal">×</button>
	      </div>
        <div class="modal-body">
        <div id="ajaxContent"></div>
        </div>
      </div><!-- /.modal-content -->
    </div><!-- /.modal-dialog -->
</div><!-- /.modal -->
<script src="<?php echo $_SESSION['url']; ?>/assets/js/bootstrap.min.js"></script> 
<script src="<?php echo $_SESSION['url']; ?>/assets/js/nprogress.js"></script>
<script src="<?php echo $_SESSION['url']; ?>/assets/js/index.js"></script>
</body>
</html>
