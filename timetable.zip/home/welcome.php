<div class="welcome">
	<div class="container">
		<p class="lead text-center">Hello there, Welcome to <a href="">timetable.io</a><br>Add your timetable, enable notification, chat with your mates and access class repository. All you need to do is login, it's that simple</p>
	</div>
</div>